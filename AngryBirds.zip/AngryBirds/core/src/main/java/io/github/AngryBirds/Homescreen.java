package io.github.AngryBirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
public class Homescreen implements Screen {
    private Main game;
    private Stage stage;
    private Texture background;
    private Texture startbuttontex;
    private Texture startbuttonhovertex;

    public Homescreen(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        background = new Texture("home screen.png");
        startbuttontex = new Texture("Start button.png");
        startbuttonhovertex = new Texture("mouse start button.png");
        TextureRegionDrawable buttonDrawable = new TextureRegionDrawable(startbuttontex);
        final ImageButton startButton = new ImageButton(buttonDrawable);
        startButton.setPosition(571, 80);
        startButton.addListener(new InputListener() {
            @Override
            public boolean mouseMoved(InputEvent event, float x, float y) {
                startButton.getStyle().imageUp = new TextureRegionDrawable(startbuttonhovertex);
                return true;
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                startButton.getStyle().imageUp = new TextureRegionDrawable(startbuttontex);
            }
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new levelselectionpage(game));
                return true;
            }
        });
        stage.addActor(startButton);
    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());  // Draw the background image stretched
        game.batch.end();
        stage.act();
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void show() {}
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {
        stage.dispose();
        background.dispose();
        startbuttontex.dispose();
        startbuttonhovertex.dispose();
    }
}
