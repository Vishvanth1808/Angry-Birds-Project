package io.github.AngryBirds;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.graphics.Texture;

public class Structure {
    private Vector2 position;
    private String type;  // Type of material: wood, stone, etc.
    private int health;
    private Texture structureTexture;

    public Structure(float x, float y, String type, String texturePath) {
        this.position = new Vector2(x, y);
        this.type = type;
        this.health = type.equals("stone") ? 200 : 100;  // Example health based on type
        this.structureTexture = new Texture(texturePath);
    }
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;
        }
    }
    public boolean isBroken() {
        return health <= 0;
    }
    public Vector2 getPosition() {
        return position;
    }
    public Texture getTexture() {
        return structureTexture;
    }
    public void dispose() {
        structureTexture.dispose();
    }
}
