package io.github.AngryBirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class levelselectionpage implements Screen {
    private Main game;
    private Stage stage;
    private Texture background;
    private Texture level1Tex;
    private Texture level1hoverTex;
    private Texture level2Tex;
    private Texture level2hoverTex;
    private Texture level3Tex;
    private Texture level3hoverTex;
    private Texture settingButTex;
    private Texture closebutTex;
    private Texture closehoverbuttex;
    private Texture settingshovertex;

    public levelselectionpage(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        background = new Texture(Gdx.files.internal("levelscreen.png"));
        level1Tex = new Texture(Gdx.files.internal("level1.png"));
        level1hoverTex = new Texture(Gdx.files.internal("level1mouse.png"));
        level2Tex = new Texture(Gdx.files.internal("level2.png"));
        level2hoverTex = new Texture(Gdx.files.internal("level2mouse.png"));
        level3Tex = new Texture(Gdx.files.internal("level3.png"));
        level3hoverTex = new Texture(Gdx.files.internal("level3mouse.png"));
        settingButTex = new Texture(Gdx.files.internal("Settingbutton.png"));
        closebutTex = new Texture(Gdx.files.internal("closebutton.png"));
        closehoverbuttex = new Texture(Gdx.files.internal("closebuttonhover.png"));
        settingshovertex = new Texture(Gdx.files.internal("Settingbuttonhover.png"));
        addLevelButton(level1Tex, level1hoverTex, 75, 240, new level1(game));

        addLevelButton(level2Tex, level2hoverTex, 477, 240,new level2(game));

        addLevelButton(level3Tex, level3hoverTex, 870, 240,  new level3(game));

        ImageButton settingsButton = createButton(settingButTex, settingshovertex, 27, 660);
        settingsButton.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new SettingScreen(game));
                return true;
            }
        });
        stage.addActor(settingsButton);
        ImageButton closeButton = createButton(closebutTex, closehoverbuttex, 1120, 660);
        closeButton.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new Homescreen(game));
                return true;
            }
        });
        stage.addActor(closeButton);
    }
    private void addLevelButton(Texture defaultTexture, Texture hoverTexture, float x, float y, final Screen nextScreen) {
        ImageButton levelButton = createButton(defaultTexture, hoverTexture, x, y);
        levelButton.addListener(new InputListener() {
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                levelButton.getStyle().imageUp = new TextureRegionDrawable(hoverTexture);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                levelButton.getStyle().imageUp = new TextureRegionDrawable(defaultTexture);
            }
            @Override
            public boolean touchDown(InputEvent event, float buttonX, float buttonY, int pointer, int button) {
                game.setScreen(nextScreen);  // Navigate to Level 1 screen
                return true;
            }
        });
        stage.addActor(levelButton);
    }
    private ImageButton createButton(Texture defaultTexture, Texture hoverTexture, float x, float y) {
        ImageButton button = new ImageButton(new TextureRegionDrawable(defaultTexture));
        button.setPosition(x, y);
        if (hoverTexture != null) {
            button.addListener(new InputListener() {
                @Override
                public boolean mouseMoved(InputEvent event, float buttonX, float buttonY) {
                    button.getStyle().imageUp = new TextureRegionDrawable(hoverTexture);
                    return true;
                }
                @Override
                public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                    button.getStyle().imageUp = new TextureRegionDrawable(defaultTexture);
                }
            });
        }

        return button;
    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        game.batch.end();

        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {
        stage.dispose();
        background.dispose();
        level1Tex.dispose();
        level1hoverTex.dispose();
        level2Tex.dispose();
        level2hoverTex.dispose();
        level3Tex.dispose();
        level3hoverTex.dispose();
        settingButTex.dispose();
        closebutTex.dispose();
        closehoverbuttex.dispose();
    }
}
