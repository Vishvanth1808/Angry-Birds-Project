package io.github.AngryBirds;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

public class Bird {
    private Vector2 position;
    private Vector2 velocity;
    private Texture birdTexture;

    public Bird(float x, float y, String texturePath) {
        this.position = new Vector2(x, y);
        this.velocity = new Vector2(0, 0);
        this.birdTexture = new Texture(texturePath);
    }
    public void launch(Vector2 initialVelocity) {
        this.velocity = initialVelocity;
    }
    public void update(float delta) {
        position.add(velocity.cpy().scl(delta));
    }
    public Vector2 getPosition() {
        return position;
    }
    public Texture getTexture() {
        return birdTexture;
    }
    public void dispose() {
        birdTexture.dispose();
    }
}
