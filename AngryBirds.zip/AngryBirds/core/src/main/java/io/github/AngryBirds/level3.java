package io.github.AngryBirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class level3 implements Screen {
    private Main game;
    private Stage stage;
    private Texture background;
    private Texture settingtex, closetex;
    private Texture settinghovertex, closehovertex;
    private Texture catapaulttex;

    public level3(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);
        background = new Texture(Gdx.files.internal("level3background.png"));
        settingtex = new Texture(Gdx.files.internal("Settingbutton1.png"));
        closetex = new Texture(Gdx.files.internal("closebutton1.png"));
        settinghovertex = new Texture(Gdx.files.internal("Settingbuttonhover.png"));
        closehovertex = new Texture(Gdx.files.internal("closebuttonhover.png"));
        catapaulttex = new Texture(Gdx.files.internal("catapault.png"));
        addButton(settingtex, settinghovertex, 27, 660, () -> {
            Gdx.app.log("Click", "Settings button clicked");
        });
        addButton(closetex, closehovertex, 1120, 660, () -> {
            Gdx.app.log("Click", "Close button clicked");
            game.setScreen(new levelselectionpage(game));  // Go back to level selection screen
        });
    }
    private void addButton(Texture defaultTexture, Texture hoverTexture, float x, float y, Runnable onClick) {
        ImageButton button = new ImageButton(new TextureRegionDrawable(defaultTexture));
        button.setPosition(x, y);
        button.addListener(new InputListener() {
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(hoverTexture);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(defaultTexture);
            }
            @Override
            public boolean touchDown(InputEvent event, float buttonX, float buttonY, int pointer, int button) {
                onClick.run();
                return true;
            }
        });
        stage.addActor(button);
    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        game.batch.draw(catapaulttex, 71, 160);
        game.batch.end();
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {
        stage.dispose();
        background.dispose();
        settingtex.dispose();
        closetex.dispose();
        settinghovertex.dispose();
        closehovertex.dispose();
    }
}
