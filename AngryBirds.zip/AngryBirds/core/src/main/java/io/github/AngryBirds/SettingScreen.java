package io.github.AngryBirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class SettingScreen implements Screen {
    private Main game;
    private Stage stage;
    private Texture background, backbuttex, backbuttonhovertex;
    private Texture rectangletex, savetex, creditex, infotex, soundtex, exitex;
    private Texture exithovertex, infohovertex, soundhovertex;

    public SettingScreen(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        background = new Texture("blurlevelscreen.png");
        backbuttex = new Texture("closebuttonset.png");
        backbuttonhovertex = new Texture("closebuttonhover1.png");
        rectangletex = new Texture(Gdx.files.internal("rectangle.png"));
        savetex = new Texture(Gdx.files.internal("save.png"));
        creditex = new Texture(Gdx.files.internal("credit.png"));
        infotex = new Texture(Gdx.files.internal("info.png"));
        soundtex = new Texture(Gdx.files.internal("sound-1.png"));
        exitex = new Texture(Gdx.files.internal("exit.png"));
        exithovertex = new Texture(Gdx.files.internal("hoverexit.png"));
        infohovertex = new Texture(Gdx.files.internal("hoverinfo.png"));
        soundhovertex = new Texture(Gdx.files.internal("hoversound.png"));
        addSettingButtons();
        ImageButton backButton = new ImageButton(new TextureRegionDrawable(backbuttex));
        backButton.setPosition(910, 570);
        backButton.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                game.setScreen(new levelselectionpage(game));
                return true;
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                backButton.getStyle().imageUp = new TextureRegionDrawable(backbuttonhovertex);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                backButton.getStyle().imageUp = new TextureRegionDrawable(backbuttex);
            }
        });
        stage.addActor(backButton);
    }
    private void addSettingButtons() {
        ImageButton rectangle=createButton(rectangletex,268,132);
        stage.addActor(rectangle);
        ImageButton saveButton=createButton(savetex,428,294);
        saveButton.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                return true;
            }
        });
        stage.addActor(saveButton);

        ImageButton creditButton = createButton(creditex,428,180);
        stage.addActor(creditButton);

        ImageButton infoButton=createButton(infotex, 438, 424);
        infoButton.addListener(createHoverListener(infoButton, infotex, infohovertex));
        stage.addActor(infoButton);

        ImageButton soundButton = createButton(soundtex, 593, 424);
        soundButton.addListener(createHoverListener(soundButton, soundtex, soundhovertex));
        stage.addActor(soundButton);

        ImageButton exitButton = createButton(exitex, 748, 424);
        exitButton.addListener(createHoverListener(exitButton, exitex, exithovertex));
        exitButton.addListener(new InputListener() {
            @Override
            public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
                Gdx.app.exit();
                return true;
            }
        });
        stage.addActor(exitButton);
    }
    private ImageButton createButton(Texture texture, float x, float y) {
        ImageButton button = new ImageButton(new TextureRegionDrawable(texture));
        button.setPosition(x, y);
        return button;
    }
    private InputListener createHoverListener(ImageButton button, Texture defaultTexture, Texture hoverTexture) {
        return new InputListener() {
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(hoverTexture);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(defaultTexture);
            }
        };
    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        game.batch.end();
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {
        stage.dispose();
        background.dispose();
        backbuttex.dispose();
        backbuttonhovertex.dispose();
        rectangletex.dispose();
        savetex.dispose();
        creditex.dispose();
        infotex.dispose();
        soundtex.dispose();
        exitex.dispose();
        exithovertex.dispose();
        infohovertex.dispose();
        soundhovertex.dispose();
    }
}
