package io.github.AngryBirds;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class level1 implements Screen {
    private Main game;
    private Stage stage;
    private Texture background, scoretex;
    private Texture endleveltex, exitex;
    private Texture endlevelhovertex, exithovertex;
    private Texture catapulttex;
    private Texture settingtex, settinghovertex;
    private Texture savetex, savehovertex;
    private boolean savebutton = false;
    private boolean showScore = false;
    private boolean exitbutton = false;

    public level1(Main game) {
        this.game = game;
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        background = new Texture(Gdx.files.internal("level1background.png"));
        endleveltex = new Texture(Gdx.files.internal("endlevel.png"));
        exitex = new Texture(Gdx.files.internal("exit.png"));
        endlevelhovertex = new Texture(Gdx.files.internal("endlevelhover.png"));
        exithovertex = new Texture(Gdx.files.internal("hoverexit.png"));
        catapulttex = new Texture(Gdx.files.internal("catapault.png"));
        settingtex = new Texture(Gdx.files.internal("Settingbutton1.png"));
        settinghovertex = new Texture(Gdx.files.internal("Settingbuttonhover.png"));
        scoretex = new Texture(Gdx.files.internal("Score.png"));
        savetex = new Texture(Gdx.files.internal("savelevel.png"));
        savehovertex = new Texture(Gdx.files.internal("savelevelhover.png"));
        addButton(settingtex, settinghovertex, 27, 660, () -> {
            Gdx.app.log("Click", "Settings button clicked");
        });
        addButton(endleveltex, endlevelhovertex, 931, 20, () -> {
            showScore = true;
            System.out.println("End Level clicked");
        });
    }
    private void addButton(Texture defaultTexture, Texture hoverTexture, float x, float y, Runnable onClick) {
        ImageButton button = new ImageButton(new TextureRegionDrawable(defaultTexture));
        button.setPosition(x, y);
        button.addListener(new InputListener() {
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(hoverTexture);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                button.getStyle().imageUp = new TextureRegionDrawable(defaultTexture);
            }
            @Override
            public boolean touchDown(InputEvent event, float buttonX, float buttonY, int pointer, int button) {
                onClick.run();
                return true;
            }
        });
        stage.addActor(button);
    }
    private void addExitButton() {
        if (!exitbutton) {
            ImageButton exitButton = new ImageButton(new TextureRegionDrawable(exitex));
            exitButton.setPosition(890, 560);
            exitButton.addListener(new InputListener() {
                @Override
                public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                    exitButton.getStyle().imageUp = new TextureRegionDrawable(exithovertex);
                }
                @Override
                public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                    exitButton.getStyle().imageUp = new TextureRegionDrawable(exitex);
                }
                @Override
                public boolean touchDown(InputEvent event, float buttonX, float buttonY, int pointer, int button) {
                    game.setScreen(new levelselectionpage(game));
                    return true;
                }
            });
            stage.addActor(exitButton);
            exitbutton = true;
        }
    }
    private void addSaveButton() {
        if (!savebutton) {
            ImageButton saveButton = new ImageButton(new TextureRegionDrawable(savetex));
            saveButton.setPosition(430, 230);
            saveButton.addListener(new InputListener() {
                @Override
                public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                    saveButton.getStyle().imageUp = new TextureRegionDrawable(savehovertex);
                }
                @Override
                public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                    saveButton.getStyle().imageUp = new TextureRegionDrawable(savetex);
                }
                @Override
                public boolean touchDown(InputEvent event, float buttonX, float buttonY, int pointer, int button) {
                    System.out.println("Game Saved");
                    return true;
                }
            });
            stage.addActor(saveButton);
            savebutton = true;
        }
    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        game.batch.begin();
        game.batch.draw(background, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        game.batch.draw(catapulttex, 71, 160);
        if (showScore) {
            game.batch.draw(scoretex, 268, 143);
            addExitButton();
            addSaveButton();
        }
        game.batch.end();
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }
    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }
    @Override
    public void hide() {}
    @Override
    public void pause() {}
    @Override
    public void resume() {}
    @Override
    public void dispose() {
        stage.dispose();
        background.dispose();
        endleveltex.dispose();
        exitex.dispose();
        endlevelhovertex.dispose();
        exithovertex.dispose();
        catapulttex.dispose();
        scoretex.dispose();
        savetex.dispose();
        savehovertex.dispose();
    }
}
