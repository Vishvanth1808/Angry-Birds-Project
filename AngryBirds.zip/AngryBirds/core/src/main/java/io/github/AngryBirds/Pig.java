package io.github.AngryBirds;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.graphics.Texture;

public class Pig {
    private Vector2 position;
    private int health;
    private Texture pigTexture;

    public Pig(float x, float y, String texturePath) {
        this.position = new Vector2(x, y);
        this.health = 100;  // Default health value, can be adjusted
        this.pigTexture = new Texture(texturePath);
    }
    public void takeDamage(int damage) {
        health -= damage;
        if (health < 0) {
            health = 0;  // Ensure health doesn’t go negative
        }
    }
    public boolean isDefeated() {
        return health <= 0;
    }
    public Vector2 getPosition() {
        return position;
    }
    public Texture getTexture() {
        return pigTexture;
    }
    public void dispose() {
        pigTexture.dispose();
    }
}

